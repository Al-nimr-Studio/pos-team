export interface SummaryObserver {

    notify(): void

}
