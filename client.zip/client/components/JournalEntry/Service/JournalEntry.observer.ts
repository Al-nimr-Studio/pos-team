export interface JournalEntryObserver {

    notify(): void

}
