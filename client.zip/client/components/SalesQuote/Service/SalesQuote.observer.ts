export interface SalesQuoteObserver {

    notify(): void

}
