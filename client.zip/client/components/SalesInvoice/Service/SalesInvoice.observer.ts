export interface SalesInvoiceObserver {

    notify(): void

}
