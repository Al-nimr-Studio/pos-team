export interface ReportsObserver {

    notify(): void

}
