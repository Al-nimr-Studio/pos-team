export interface InventoryItemObserver {

    notify():void

}
