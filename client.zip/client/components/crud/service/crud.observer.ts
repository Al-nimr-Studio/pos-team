export interface CrudObserver {

    notify():void

}
