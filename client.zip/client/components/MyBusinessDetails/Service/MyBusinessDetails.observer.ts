export interface MyBusinessDetailsObserver {

    notify(): void

}
