export interface PurchaseOrderObserver {

    notify():void

}
