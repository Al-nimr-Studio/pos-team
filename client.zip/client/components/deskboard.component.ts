import {Component} from "@angular/core";

@Component({
    selector: 'deskboard',
    template: require('../components/deskboard.component.html')

})
export class DeskboardComponent {
}
