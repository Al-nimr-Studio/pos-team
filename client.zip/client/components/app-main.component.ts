import { Component } from "@angular/core";



@Component({
    selector: 'app-main',
    template: require('../components/app-main.component.html'),
    styles: [``]

})
export class AppMainComponent {
    // constructor(){
    //     console.log("yesssssss")
    // }
}
