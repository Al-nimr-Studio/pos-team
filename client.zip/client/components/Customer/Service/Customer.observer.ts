export interface CustomerObserver {

    notify(): void

}
