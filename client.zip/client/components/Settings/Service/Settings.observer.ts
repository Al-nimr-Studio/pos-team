export interface SettingsObserver {

    notify(): void

}
