export interface SupplierObserver {

    notify():void

}
