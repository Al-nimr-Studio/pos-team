export interface SalesOrderObserver {

    notify(): void

}
