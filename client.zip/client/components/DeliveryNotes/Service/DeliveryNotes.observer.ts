export interface DeliveryNotesObserver {

    notify(): void

}
