export interface PurchaseInvoiceObserver {

    notify():void

}
