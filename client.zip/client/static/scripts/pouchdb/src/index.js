import PouchDB from './pouchdb';
export default PouchDB;