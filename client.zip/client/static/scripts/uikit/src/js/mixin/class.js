export default {

    init() {
        this.$el.addClass(this.$name);
    }

}
